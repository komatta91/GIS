var searchData=
[
  ['totaledgestovisit',['totalEdgesToVisit',['../class_console_application3_c_s_h_a_r_p_1_1_graph.html#a4df35e901ccf75b591f6a58be25182ca',1,'ConsoleApplication3CSHARP::Graph']]],
  ['totaledgesvisited',['totalEdgesVisited',['../class_console_application3_c_s_h_a_r_p_1_1_graph.html#abb574417890ceef203c9757e1a1f8ab9',1,'ConsoleApplication3CSHARP::Graph']]]
];
